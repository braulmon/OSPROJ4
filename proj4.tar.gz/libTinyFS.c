#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include "libDisk.h"
#include "libTinyFS.h"

void initialize_fd_table() {
    for (int i = 0; i < MAX_FILES; i++) {
        fd_table[i] = -1;
    }
}

int allocate_inode() {
    // implement allocating inode
}


int tfs_mkfs(char *filename, int nBytes)
{
    // openDisk has its own error checks already
    int disk = openDisk(filename, nBytes);

    // Initialize superblock
    Block superblock;
    superblock.block_type = SUPERBLOCK_TYPE;
    superblock.magic_number = MAGIC_NUMBER;
    superblock.next_block = 0;
    superblock.padding = 0;
    memset(superblock.data, 0, sizeof(superblock.data));

    Superblock *sb = (Superblock *)superblock.data;
    sb->root_inode = 1;
    sb->free_block_list = 2;

    if (writeBlock(disk, 0, &superblock) < 0) {
        return -1;
    }

    // Initialize free blocks
    for (int i = 1; i < nBytes / BLOCKSIZE; i++) {
        block.block_type = FREE_BLOCK_TYPE;
        block.magic_number = MAGIC_NUMBER;
        supeblock.next_block = 0;
        superblock.padding = 0;
        memset(superblock.data, 0, sizeof(superblock.data));
        if (i == nBytes / BLOCKSIZE - 1) {
            block.next_block = 0;
        } else {
            block.next_block = i + 1;
        }

        if (writeBlock(disk, i, &block) < 0) {
            return -1;
        }
    }

    return 0;
}

int tfs_mount(char *diskname) {
    // openDisk with 0 nBytes input to parameter means disk exists
    int disk = openDisk(diskname, 0);

    if (disk < 0) {
        return -1;
    }

    Block superblock;
    if (readBlock(disk, 0, &superblock) < 0) {
        return -1;
    }

    if (superblock.magic_number != MAGIC_NUMBER || superblock.block_type != SUPERBLOCK_TYPE) {
        perror("Invalid superblock");
        return -1;
    }

    current_mounted_disk = disk;

    return 0;
}


int tfs_unmount(void) {
    if (current_mounted_disk < 0) {
        perror("No disk is currently mounted: tfs_unmount");
        return -1;
    }

    if (closeDisk(current_mounted_disk) < 0) {
        perror("Failed to unmount fs: tfs_unmount");
        return -1;
    }

    current_mounted_disk = -1;

    return 0;
}

fileDescriptor tfs_openFile(char *name)
{

    int fd = -1;
    for (int i = 0; i < 50; i++) {
        if (fd_table[i] == -1) {
            // Find and initialize an available inode
            Inode inode;
            strcpy(inode.file_name, name);
            inode.file_size = 0;
            inode.start_block = -1;
            inode.block_count = 0;
            inode.read_only = 0;
            inode.creation_time = time(NULL);
            inode.modification_time = time(NULL);
            inode.access_time = time(NULL);

            int inode_block = allocate_inode(); // implement function
            if (inode_block < 0) {
                return -1;
            }

            if (writeBlock(current_mounted_disk, inode_block, &inode) < 0) {
                return -1;
            }

            fd_table[i] = inode_block;
            return i;
        }
    }

    return -1;
}

//Remainder math
//take the offset
//divide by how much is left
//


int tfs_closeFile(fileDescriptor FD)
{/* Closes the file, de-allocates all system resources, and removes table
entry */
    if (FD < 0)
    {
        return -1;
    }



    for(int i = 0; i < MAX_FILES; i++){
        if(fd_table[i] == FD){
            fd_table[i] = -1;
        }
    }




   /* int flags = fcntl(FD, F_GETFD);
    if (flags & FD_CLOEXEC)
    {
        // The file descriptor is not in use - NOTE this was found by generative AI when searched on google
        printf("tfs_closeFile: File is not open\n");
        return -1;
    }
    else
    {
        close(FD);
        return 0;
    }*/
}

int tfs_writeFile(fileDescriptor FD, char *buffer, int size)
{
    
}

int tfs_deleteFile(fileDescriptor FD)
{
    // implement
}


int tfs_readByte(fileDescriptor FD, char *buffer) {
    // implement
}



int tfs_seek(fileDescriptor FD, int offset) {
    // implement
}
