#ifndef LIBTINYFS_H
#define LIBTINYFS_H

#include <time.h>

/* The default size of the disk and file system block */
#define BLOCKSIZE 256
#define MAGIC_NUMBER 0x44
#define SUPERBLOCK_TYPE 1
#define INODE_TYPE 2
#define FILE_EXTENT_TYPE 3
#define FREE_BLOCK_TYPE 4

#define DEFAULT_DISK_SIZE 10240
#define DEFAULT_DISK_NAME "tinyFSDisk"

typedef int fileDescriptor;

typedef struct {
    char block_type;
    char magic_number;
    char next_block;
    char padding;
    char data[BLOCKSIZE - 4];
} Block;

typedef struct {
    char magic_number;
    int root_inode;
    int free_block_list;
} Superblock;

typedef struct {
    char file_name[8];
    int file_size;
    int start_block;
    int block_count;
    int read_only;
    time_t creation_time;
    time_t modification_time;
    time_t access_time;
} Inode;

extern int fd_table[50];
extern int current_mounted_disk;

int tfs_mkfs(char *filename, int nBytes);
int tfs_mount(char *diskname);
int tfs_unmount(void);
fileDescriptor tfs_openFile(char *name);
int tfs_closeFile(fileDescriptor FD);
int tfs_writeFile(fileDescriptor FD, char *buffer, int size);
int tfs_deleteFile(fileDescriptor FD);
int tfs_readByte(fileDescriptor FD, char *buffer);
int tfs_seek(fileDescriptor FD, int offset);
int add_fd(fileDescriptor FD);

#endif // LIBTINYFS_H
